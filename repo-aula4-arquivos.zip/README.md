# Sistema de Gestão de Academia
Projeto 2 · Serviços em Nuvem · 2026.02

Integrantes: André Drumond, Eduardo Barbizan, Gabriel Henrique, Gustavo Frainer.

Landing page: http://academia-frontend.s3-website-us-east-1.amazonaws.com

Sistema (front-end com CRUD, upload e relatórios): http://academia-frontend-365180416721.s3-website-us-east-1.amazonaws.com

## Documentação
- Especificação: [specs/spec.md](specs/spec.md)
- Design/arquitetura/ADRs: [specs/design.md](specs/design.md)
- Log de IA: [specs/ia-log.md](specs/ia-log.md)
- Tarefas: [specs/tasks.md](specs/tasks.md)
- Segurança e Security Groups: [docs/seguranca.md](docs/seguranca.md)

## Aula 4 · Upload, evento S3 → Lambda → RDS e relatórios

**Código:** `backend/presign/`, `backend/miniatura/`, `backend/relatorios/` (Python 3.12) e `frontend/aula4.js` + `frontend/aula4-secoes.html` (trecho acrescentado ao front publicado). A tabela `arquivo` já existe no schema; não houve alteração de banco.

**Pacotes das Lambdas.** Cada pasta de `backend/` vira um ZIP com o `handler.py` na raiz mais as dependências
(`pip install --target build/<lambda> --platform manylinux2014_x86_64 --python-version 3.12 --only-binary=:all: pymysql` e, só para a miniatura, também `Pillow`).

**Recursos criados (console/CloudShell, sem IaC, conforme RNF-05):**

1. Bucket de uploads `academia-uploads-<id-da-conta>`: Block Public Access ligado e CORS com `PUT, GET, HEAD`.
2. Lambda `academia-presign` (LabRole, VPC, `academia-sg-lambda`, 15 s, 256 MB). Variáveis: `UPLOAD_BUCKET`, `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`.
3. Lambda `academia-miniatura` (mesma rede, 30 s, 512 MB). Mesmas variáveis, sem `UPLOAD_BUCKET`. Gatilho S3: `s3:ObjectCreated:*` com **prefixo `uploads/`** (miniaturas vão para `thumbs/`, o que evita loop de eventos).
4. Lambda `academia-relatorios` (mesma rede). Variáveis: `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`.
5. API Gateway (HTTP API): `POST /alunos/{id}/arquivos/presign` e `GET /alunos/{id}/arquivos` → presign; `GET /relatorios/ocupacao-aulas` e `GET /relatorios/alunos-por-plano` → relatorios.
6. Front: o conteúdo de `frontend/aula4.js` fica no fim do `app.js` e as seções de `frontend/aula4-secoes.html` entram no `index.html`; depois é só publicar no bucket do site.

**Teste executado (28/10/2026):** upload de um PNG 400x300 → miniatura 150x150 em `thumbs/` → `tamanho_bytes`, `largura`, `altura` e `chave_thumb` gravados no RDS em cerca de 1 s → log "Miniatura criada ... linhas atualizadas no RDS: 1" no CloudWatch. Os dois relatórios respondem HTTP 200 e aparecem na aba Relatórios do site.

**Recriar em uma nova sessão do Learner Lab (RNF-03):**
1. Iniciar o lab e esperar o RDS ficar `Available` (o endpoint não muda ao parar e iniciar).
2. Conferir se a URL da API é a mesma do `config.js`; se algo foi recriado, atualizar `DB_HOST` nas Lambdas e o `config.js` do front.
3. Se o bucket de uploads precisar ser recriado: Block Public Access, CORS (`PUT, GET, HEAD`), gatilho no prefixo `uploads/` e a permissão da Lambda `academia-miniatura`.
4. Ao terminar, clicar em **End Lab** (o RDS e as instâncias ficam parados; custos de NAT/EIP/armazenamento não existem neste projeto).
